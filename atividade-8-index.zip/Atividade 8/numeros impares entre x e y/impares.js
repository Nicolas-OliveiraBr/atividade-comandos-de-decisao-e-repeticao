var x = Number(prompt("Digite um número aleatório:"))
var y = Number(prompt("Digite outro número:"))
var somaImpares = 0

while(x >= y) {
    Number(prompt("Digite um número aleatório(certifique-se de de que esse número seja menor que o próximo):"))
    Number(prompt("Digite outro número(maior que o anterior):"))
    break
}

for(x; x <= y; x++){
    if(x % 2 != 0){
        somaImpares += x
        
    }
}

var z = `A soma dos números ímpares entre esses números é de ${somaImpares}.`

alert(z)

