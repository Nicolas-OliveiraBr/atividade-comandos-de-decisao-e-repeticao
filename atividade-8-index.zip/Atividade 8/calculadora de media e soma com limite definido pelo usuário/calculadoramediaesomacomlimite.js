var limite = parseInt(prompt(`Digite o limite requerido: `))
var total = 0
var media
var x
var valor = 0

while(valor < limite) {
   x = Number(prompt(`Digite o ${valor + 1}° valor:`))
   total += x
   valor++
}

media = total / limite

let mensagem = `A soma equivale a ${total} e a média é igual a ${media}.`

alert(mensagem)

