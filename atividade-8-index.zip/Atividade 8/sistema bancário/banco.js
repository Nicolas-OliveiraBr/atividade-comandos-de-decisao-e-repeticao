let saldoInicial = prompt('Digite seu saldo atual: ')
let produto = prompt('Digite o nome do produto que deseja comprar: ')
let valorProduto = prompt('Digite o valor da compra que quer realizar: ')

const valorFinal = saldoInicial - valorProduto
const restante = valorProduto - saldoInicial

const compraFeita = (`A compra foi realizada com sucesso! Você comprou um(a) ${produto} e seu saldo é de ${valorFinal} reais.`)
const compraCancelada = (`Saldo Insuficiente! Você precisa de mais ${restante} reais para completar a compra.`)

if (saldoInicial>=valorProduto) {
    alert(compraFeita)
}

if (saldoInicial<valorProduto) {
    alert(compraCancelada)
}