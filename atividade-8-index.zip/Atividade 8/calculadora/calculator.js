const y = prompt('Digite um número inteiro aleatório: ' )
const x = prompt('Digite outro número inteiro aleatório (pode ser o mesmo do anterior): ')
var sinal = prompt('Digite o sinal da operação que quer realizar: ')

var add = `O resultado da adição é ${y*1 + x*1}.`
var less = `O resultado da subtração é ${y - x}.`
var times = `O resultado da multiplicação é ${y * x}.`
var dividedBy = `O resultado da divisão é ${y / x}.`

if (sinal === '+') {
    alert(add);
} else if (sinal ==='-') {
    alert(less);
} else if (sinal === '*') {
    alert(times);
} else if (sinal === '/') {
    alert(dividedBy);
}